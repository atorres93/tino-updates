# Blocklists

WebKit content rule lists that the app compiles at launch (see `ContentBlocker.swift`).

- `easylist-*.json`: [EasyList](https://easylist.to/), which blocks ads.
- `easyprivacy-*.json`: [EasyPrivacy](https://easylist.to/), which blocks trackers.
- `cookie-banners-*.json`: the [EasyList Cookie List](https://easylist.to/), which hides cookie consent banners.
- `notification-prompts-*.json`: Fanboy's Notifications list, which hides pages' own pop-ups asking to send notifications.
- `third-party-cookies.json`: strips cookies from every request to a site other than the one you're on.

The EasyList and Fanboy files are generated: run `scripts/update-blocklists.py` to
download the latest lists and convert them. The cookie banner and notification lists are
parts of Fanboy's Annoyance List. `VERSIONS.txt` records which versions they were made from.
The converted lists are split into parts of at most 50,000 rules, which every
WebKit version accepts.

EasyList, EasyPrivacy and Fanboy's lists are by The EasyList authors, licensed under
[CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) (or GPL 3), and the
converted files are under the same licence.
